#  COVID-19 data
 Creating a Python script to fetch the latest COVID-19 data.
 For Indian states from the API URL: https://data.covid19india.org/v4/min/timeseries.min.json.
 The script prints the response of the JSON data.
 ### Python Libraries :
 ##### In this code importing python libraries are:
 - requests
 - json
   
 'requests' library to get the data from API.
 
 'json' library to give the data in json format. 

